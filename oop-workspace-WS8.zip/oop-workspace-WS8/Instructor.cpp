#include "Instructor.h"

Instructor::Instructor(const std::string& name) 
    : Person(name) {}
